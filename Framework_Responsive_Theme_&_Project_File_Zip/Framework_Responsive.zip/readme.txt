Welcome.

This file is licensed under the Afterburner Theme License which can be found at this address:
http://www.afterburnerapp.com/license/