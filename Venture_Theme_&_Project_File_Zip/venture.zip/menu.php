<nav role="navigation">
            <div class="skip-link screen-reader-text"><a href="#content" title="Skip to content">Skip to content</a></div>
            <div id="centeredmenu" class="abrn_menu_sub"><?php echo(mytheme_nav("dropmenu",0)); ?></div>
        </nav><!-- nav -->  
        
